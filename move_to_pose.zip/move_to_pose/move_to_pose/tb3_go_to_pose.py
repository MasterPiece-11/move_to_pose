import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped, Pose2D
from nav_msgs.msg import Odometry


def normalize_angle(angle: float) -> float:
    return math.atan2(math.sin(angle), math.cos(angle))


def quaternion_to_yaw(q) -> float:
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class TB3GoToPose(Node):
    def __init__(self):
        super().__init__('tb3_go_to_pose')
        self.cmd_pub = self.create_publisher(TwistStamped, '/cmd_vel', 10)
        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        self.goal_sub = self.create_subscription(Pose2D, '/topic_goal', self.goal_cb, 10)

        self.x = None
        self.y = None
        self.theta = None
        self.goal_pose = None

        # Conservative gains for Gazebo physics
        self.k_rho = 0.3
        self.k_alpha = 0.8
        self.k_beta = -0.2

        self.timer = self.create_timer(0.05, self.control_loop)
        self.get_logger().info('TB3 GoToPose ready (TwistStamped). Publish Pose2D to /topic_goal.')

    def odom_cb(self, msg: Odometry):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.theta = quaternion_to_yaw(msg.pose.pose.orientation)

    def goal_cb(self, msg: Pose2D):
        self.goal_pose = msg
        self.get_logger().info(f'New TB3 goal: x={msg.x:.2f}, y={msg.y:.2f}, theta={msg.theta:.2f}')

    def control_loop(self):
        if self.x is None or self.goal_pose is None:
            return

        dx = self.goal_pose.x - self.x
        dy = self.goal_pose.y - self.y
        rho = math.hypot(dx, dy)
        theta_err = normalize_angle(self.goal_pose.theta - self.theta)

        cmd = TwistStamped()
        cmd.header.stamp = self.get_clock().now().to_msg()
        cmd.header.frame_id = 'base_link'

        if rho < 0.05 and abs(theta_err) < 0.05:
            self.cmd_pub.publish(cmd)
            self.get_logger().info('TB3 goal reached!')
            self.goal_pose = None
            return

        if rho < 0.05:
            cmd.twist.linear.x = 0.0
            cmd.twist.angular.z = max(min(1.0 * theta_err, 1.5), -1.5)
        else:
            angle_to_goal = math.atan2(dy, dx)
            alpha = normalize_angle(angle_to_goal - self.theta)
            beta = normalize_angle(self.goal_pose.theta - angle_to_goal)

            v = self.k_rho * rho
            w = self.k_alpha * alpha + self.k_beta * beta

            # TurtleBot3 Burger velocity limits
            cmd.twist.linear.x = max(min(v, 0.22), -0.22)
            cmd.twist.angular.z = max(min(w, 2.0), -2.0)

        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = TB3GoToPose()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
