import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Pose2D
from turtlesim.msg import Pose


def normalize_angle(angle: float) -> float:
    return math.atan2(math.sin(angle), math.cos(angle))


class TurtleSimGoToPose(Node):
    def __init__(self):
        super().__init__('turtlesim_go_to_pose')
        self.cmd_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.pose_sub = self.create_subscription(Pose, '/turtle1/pose', self.pose_cb, 10)
        self.goal_sub = self.create_subscription(Pose2D, '/topic_goal', self.goal_cb, 10)

        self.current_pose = None
        self.goal_pose = None

        # Proportional gains (k_rho > 0, k_beta < 0, k_alpha > k_rho)
        self.k_rho = 1.0
        self.k_alpha = 3.0
        self.k_beta = -0.8

        self.timer = self.create_timer(0.05, self.control_loop)
        self.get_logger().info('TurtleSim GoToPose ready. Publish Pose2D to /topic_goal.')

    def pose_cb(self, msg: Pose):
        self.current_pose = msg

    def goal_cb(self, msg: Pose2D):
        self.goal_pose = msg
        self.get_logger().info(f'New goal: x={msg.x:.2f}, y={msg.y:.2f}, theta={msg.theta:.2f}')

    def control_loop(self):
        if self.current_pose is None or self.goal_pose is None:
            return

        dx = self.goal_pose.x - self.current_pose.x
        dy = self.goal_pose.y - self.current_pose.y
        rho = math.hypot(dx, dy)
        theta_err = normalize_angle(self.goal_pose.theta - self.current_pose.theta)

        cmd = Twist()

        # Stop when both position and orientation are within tolerance
        if rho < 0.05 and abs(theta_err) < 0.05:
            self.cmd_pub.publish(cmd)
            self.get_logger().info('Goal reached!')
            self.goal_pose = None
            return

        if rho < 0.05:
            # Fine-tune final heading
            cmd.linear.x = 0.0
            cmd.angular.z = max(min(2.0 * theta_err, 2.0), -2.0)
        else:
            angle_to_goal = math.atan2(dy, dx)
            alpha = normalize_angle(angle_to_goal - self.current_pose.theta)
            beta = normalize_angle(self.goal_pose.theta - angle_to_goal)

            v = self.k_rho * rho
            w = self.k_alpha * alpha + self.k_beta * beta

            # Clamp velocities
            cmd.linear.x = max(min(v, 2.0), -2.0)
            cmd.angular.z = max(min(w, 4.0), -4.0)

        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleSimGoToPose()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
